// fazer um array de 10 elemento do tipo int que sera preenchido pelo usuario 
// e mostrar um outro array com o dobro do informado pelo usuario
package at1;

import java.util.Scanner;

public class At1 {

    public static void main(String[] args) {
       
        Scanner scan = new Scanner(System.in);
        
        int array[];
        array = new int [10];
        
        for(int counter = 0; counter < array.length; counter++) 
        {
            System.out.println("Informe o numero: ");
            array[counter] = scan.nextInt(); 
        }
        
        System.out.println("Vetor original: ");
        
        for(int counter2 = 0; counter2 < array.length; counter2++) 
        {
            System.out.printf(",", counter2, array[counter2]);
        }
    }
    
}
